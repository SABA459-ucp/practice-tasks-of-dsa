#include<iostream>
using namespace std;
template<class T>
int linearSearch(T arr[] ,int size,T key
    
    for(int i = 0;i<size;i++){
            if(arr[i] == key){
                      return i;
                      }

return -1;

int main(){
    
    int arr[5= {5,7,8,4,3};
     cout << "Index of 3: " << linearSearch(arr, 5,4;
return 0;
}
    
