#include<iostream>
using namespace std;
template<class T>
int binarySearch(T arr[];int size;T key)}{
    int low = 0;
    int high = size -1;
    while(low <= high){

int mid = (low+high)/2;
if(arr[mid]==value){
               return mid;
}           
else if(arr[mid]<value){
     
     low = mid+1;
     }
     else{
          high = mid -1;
          }
          
          
          
     return -1;
     }
     int main(){
         int arr[5] = {5,7,8,9,2};
         cout<<"2 index of array is "<<binarySearch(arr,5,8);
         
         return 0;
         }
         
