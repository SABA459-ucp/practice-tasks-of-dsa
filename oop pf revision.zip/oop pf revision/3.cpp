#include<iostream>
using namespace std;
template<class T>
int sorting(T arr[],int size){
    for(int i = 0;i<size-1;i++){
            int minIndex = i;
            for(int j = i+1;j<size;j++){
                    
            if(arr[j]<arr[minIndex])
            minIndex = j;
            
            }
            
            T temp = arr[i];
            arr[i] = arr[minIndex];
            arr[minIndex] =T  temp;
            }
            
}


int main(){
    
    int arr[10] = {6, 1, 9, 2, 8, 4, 10, 3, 7, 5};

    sorting(arr,3);

    cout << "Sorted array: ";
    for (int i = 0; i < 10; i++)
        cout << arr[i] << " ";

    return 0;
}
                                     
            
            
            
            
            
